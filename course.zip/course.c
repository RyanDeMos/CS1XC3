#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This function adds a student the the students array member of a course struct.
 * 
 * @param course The course to enroll the student in.
 * @param student The student to enroll in the course.
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // If the course doesn't have any students already then create the student array
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // Else reallocate enough room for the array with the new student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints information of the course.
 * Prints the name, code, and all the students in the course.
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/**
 * @brief Calculates and returns the student with the highest average in the course
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  // If there are no students return null
  if (course->total_students == 0) return NULL;
 
  // Finds the max student average by keeping track of the highest average seen and looping through all of the students
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // If the average of the current student is higher than the previously seen highest then update the highest seen with the new student
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief 
 * Finds the number of students who are passing the course and records them in an array
 * 
 * @param course 
 * @param total_passing A count of the number of passing students
 * @return Returns an student array of passing students. Students*
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Loops over the students counting the passing ones
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));
  
  // Loops over the students adding the passing students to the array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}