/**
 * @file course.h
 * @author your name (you@domain.com)
 * @brief Containts the typdef for the course struct
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief 
  * Course has 4 members
  * course->name is a char array for the name of the course
  * course->code is a char array for the course code ie Compsci 1XC3
  * course->students is an array of the student struct for a list of the students in the course
  * course->total_students is the total amount of students
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


