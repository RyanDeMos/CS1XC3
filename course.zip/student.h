  /**
  * @brief 
  * Contains the typdef for the student struct
  * Student has 5 members
  * Student->first_name is a char array for the first name of the student
  * Student->last_name is a char array for the last name of the student
  * Student->id is a char array for the student id number
  * Student->grades is an array containing the student's grades
  * Student->num_grades is the number of grades in the "grades" array
  */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
